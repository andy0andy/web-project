import sys
import os
curPath = os.path.abspath(os.path.dirname(__file__))
rootPath = os.path.split(curPath)[0]
sys.path.append(rootPath)

from fastapi import FastAPI
import uvicorn
from fastapi.requests import Request
from starlette.staticfiles import StaticFiles
from starlette.templating import Jinja2Templates
from sqlalchemy import desc, func

import settings
from Model.anquanke import AquankeModel



app = FastAPI()
app.mount("/static", StaticFiles(directory="static"), name="static")

templates = Jinja2Templates(directory="Template")


DBsession = settings.mysql_session


@app.get("/")
def index(request: Request, page: int = 0, offset: int = 10):

    querys = DBsession.query(AquankeModel).order_by(desc(AquankeModel.update)).offset(page*offset).limit(offset)
    
    # 或取数据总量
    counts = DBsession.query(func.count(AquankeModel.id)).scalar()

    context = {
        "request": request,
        "querys": querys,
        "counts": counts
    }

    return templates.TemplateResponse("index.html", context)





if __name__ == "__main__":


    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True, debug=True)






