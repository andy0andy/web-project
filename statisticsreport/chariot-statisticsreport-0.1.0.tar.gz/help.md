# 统计报表

## About
集成统计各插件报告，并以规定格式返回

## Actions

### merge



#### Input

|Name|Type|Required|Description|Default|
|----|----|--------|-----------|-------|
|name|string|false||<no value>|
|reports|array|true||<no value>|


#### Output

|Name|Type|Required|Description|Default|
|----|----|--------|-----------|-------|
|code|integer|true||<no value>|
|msg|string|true||<no value>|
|report|file|false||<no value>|


## Triggers



## Connection

|Name|Type|Required|Description|
|----|----|--------|-----------|


## Types



## 版本信息

## 参考引用