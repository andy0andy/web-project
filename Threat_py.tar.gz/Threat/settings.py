import os
import sys
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, scoped_session


BASE_DIR = os.path.abspath(os.path.dirname(__file__))





# 数据库


def joindb(db):

    try:
        str = f"mysql+pymysql://{db['user']}:{db['pwd']}@{db['host']}:{db['port']}/{db['db']}"
    except Exception as e:
        raise Exception("数据库连接失败")

    return str


DATABASE = {
    "mysql": {
        "host": "127.0.0.1",
        "port": 3306,
        "user": "root",
        "pwd": "123456andy",
        "db": "threatreport"
    }
}

mysql_engine = create_engine(joindb(DATABASE['mysql']))

mysql_session = scoped_session(sessionmaker(bind=mysql_engine)) 







