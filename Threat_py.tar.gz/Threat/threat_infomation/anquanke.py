import requests
from faker import Faker
from loguru import logger
from lxml import etree
from queue import Queue
import threading

import sys
import os
curPath = os.path.abspath(os.path.dirname(__file__))
rootPath = os.path.split(curPath)[0]
sys.path.append(rootPath)


import settings
from Model.anquanke import AquankeModel
from Model.increment import BloomFilter

fake = Faker()


session = settings.mysql_session


'''
安全客漏洞数据抓取
'''



class Anquanke(object):

    def __init__(self):
        self.base_url = "https://www.anquanke.com/vul"


    def oneListPage(self, page: str) -> str:
        '''
        抓取列表单页
        '''

        headers = {
            "User-Agent": fake.user_agent(),
            "Referer": "https://www.anquanke.com/vul",
            "Host": "www.anquanke.com"
        }

        params = {
            "page": page
        }

        try:
            html = requests.get(self.base_url, headers=headers, params=params).text
        except Exception as e:
            logger.debug(f"第 {page} 页抓取错误 - {str(e)}")
            html = ""

        return html


    def parseListPage(self, text: str) -> dict:
        '''
        解析列表页
        '''

        html = etree.HTML(text, parser=etree.HTMLParser())


        trs = html.xpath("//tbody/tr")

        for tr in trs:
            item = {}
            
            item["title"] = "".join(tr.xpath(".//div[@class='vul-title-item']/a/text()")).replace("\n", "").replace("\t", "")
            item['cve'] = "".join(tr.xpath("./td[@class='vul-cve-item']/a/text()"))
            item['publish'] = "".join(tr.xpath("./td[@class='vul-date-item'][position()=1]/text()")).replace("\n", "").strip()
            item['update'] = "".join(tr.xpath("./td[@class='vul-date-item'][position()=2]/text()")).replace("\n", "").strip()

            item['detail_url'] = "".join(tr.xpath(".//div[@class='vul-title-item']/a/@href"))[4:]

            yield item



    def oneDetailPage(self, detail_url: str) -> str:
        '''
        抓取详情页
        '''

        url = self.base_url + detail_url

        headers = {
            "User-Agent": fake.user_agent(),
            "Referer": "https://www.anquanke.com/vul",
            "Host": "www.anquanke.com"
        }



        try:
            html = requests.get(url, headers=headers).text
        except Exception as e:
            logger.debug(f"{detail_url} 抓取错误 - {str(e)}")
            html = ""

        return html


    def parseDetailPage(self, text: str) -> dict:
        '''
        解析详情页
        '''

        html = etree.HTML(text, parser=etree.HTMLParser())

        item = {}

        item['type'] = "".join(html.xpath("//tbody/tr[position()=1]/td[@class='vul-info-value'][position()=2]/text()"))
        item['cnnvd-id'] = "".join(html.xpath("//tbody/tr[position()=3]/td[@class='vul-info-value'][position()=2]/text()"))
        item['cubes'] = "".join(html.xpath("//tbody/tr[position()=4]/td[@class='vul-info-value'][position()=1]/span/text()"))
        item['cvss'] = "".join(html.xpath("//tbody/tr[position()=4]/td[@class='vul-info-value'][position()=2]/span/text()"))
        item["vul_from"] = "".join(html.xpath("/html/body/main/div/div/div/div[1]/div[2]/div/a/@href"))
        item["info"] = "".join(html.xpath("//div[@class='common-left-content-container article-detail'][position()=3]/div[@class='article-content']/text()")).replace("\n", "").strip()

        return item





def work(q):
    # 任务函数

    while not q.empty():

        page = q.get()


        aqk = Anquanke()

        text = aqk.oneListPage(page)

        if text:
            items = aqk.parseListPage(text)

            for item in items:

                text = aqk.oneDetailPage(item['detail_url'])

                if not text:
                    continue

                data = aqk.parseDetailPage(text)

                data.update(item)
                data['detail_url'] = aqk.base_url + data['detail_url']


                # 保存数据
                bf = BloomFilter()

                if bf.isContains("anquanke", data['detail_url']):
                    logger.warning(f"{data['detail_url']} 重复抓取")
                    continue
                else:
                    aqk_obj = AquankeModel()
                    aqk_obj.title = data.get('title')
                    aqk_obj.cve = data.get('cve')
                    aqk_obj.publish = data.get('publish')
                    aqk_obj.update = data.get('update')
                    aqk_obj.type = data.get('type')
                    aqk_obj.cnnvd_id = data.get('cnnvd_id')
                    aqk_obj.cubes = data.get('cubes')
                    aqk_obj.cvss = data.get('cvss')
                    aqk_obj.vul_from = data.get("vul_from")
                    aqk_obj.info = data.get('info')

                    try:
                        session.add(aqk_obj)
                        session.commit()
                        
                        bf.insert("anquanke", data['detail_url'])
                        
                        logger.info(f"{data.get('title')} - 入库成功")
                    except:
                        logger.warning(f"{data.get('detail_url')} - 入库失败")
                        session.rollback()

                
        



def run():
    # 多线程

    q = Queue()

    for i in range(32544):
        q.put(str(i))


    t_list = []

    for i in range(12):
        t = threading.Thread(target=work, args=(q,))
        t.start()
        t_list.append(t)


    for t in t_list:
        t.join()




if __name__ == "__main__":
    
    run()



    ...




