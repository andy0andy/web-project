import redis
from hashlib import md5
from loguru import logger


# 增量爬取
# https://www.bookstack.cn/read/piaosanlang-spiders/f714e8208860486c.md



class SimpleHash(object):
    def __init__(self, cap, seed):
        self.cap = cap
        self.seed = seed
    def hash(self, value):
        ret = 0
        for i in range(len(value)):
            ret += self.seed * ret + ord(value[i])
        return (self.cap - 1) & ret

class BloomFilter(object):

    def __init__(self, host='localhost', port=6379, db=0, pwd=None, blockNum=1):
        """
        :param host: the host of Redis
        :param port: the port of Redis
        :param db: witch db in Redis
        :param blockNum: one blockNum for about 90,000,000; if you have more strings for filtering, increase it.
        """
        self.server = redis.Redis(host=host, port=port, db=db, password=pwd)
        self.bit_size = 1 << 31  # Redis的String类型最大容量为512M，现使用256M= 2^8 *2^20 字节 = 2^28 * 2^3bit
        self.seeds = [5, 7, 11, 13, 31, 37, 61]
        self.blockNum = blockNum
        self.hashfunc = []
        for seed in self.seeds:
            self.hashfunc.append(SimpleHash(self.bit_size, seed))


    def isContains(self, name, value):
        if not value:
            return False
        m5 = md5()
        m5.update(value.encode())
        value = m5.hexdigest()
        ret = True
        for f in self.hashfunc:
            loc = f.hash(value)
            ret = ret & self.server.getbit(name, loc)
        return ret
        
    def insert(self, name, value):
        m5 = md5()
        m5.update(value.encode())
        value = m5.hexdigest()
   
        for f in self.hashfunc:
            loc = f.hash(value)
            self.server.setbit(name, loc, 1)


    








if __name__ == "__main__":

    bf = BloomFilter()

    url = "https://www.anquanke.com/vul/id/2336055"

    if bf.isContains("anquanke", url):
        print(f"{url} 存在")
    else:
        bf.insert("anquanke", url)





